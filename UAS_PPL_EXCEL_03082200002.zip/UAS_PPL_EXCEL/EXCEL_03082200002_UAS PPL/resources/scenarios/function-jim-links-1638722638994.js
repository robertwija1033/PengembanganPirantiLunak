(function(window, undefined) {

  var jimLinks = {
    "5356b72f-e3db-48c7-ae4e-c6ccb43a204c" : {
      "Rectangle_14" : [
        "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"
      ],
      "Rectangle_15" : [
        "9d7e289a-9886-4c55-8d5d-ff8546563551"
      ],
      "Rectangle_16" : [
        "56646bc4-b8ac-4945-946b-9253c00691c3"
      ]
    },
    "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f" : {
      "Rectangle_16" : [
        "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"
      ],
      "Image_6" : [
        "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"
      ]
    },
    "9d7e289a-9886-4c55-8d5d-ff8546563551" : {
      "Rectangle_15" : [
        "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"
      ],
      "Image_4" : [
        "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"
      ]
    },
    "56646bc4-b8ac-4945-946b-9253c00691c3" : {
      "Rectangle_16" : [
        "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"
      ],
      "Image_4" : [
        "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);