	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Rectangle", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Paragraph_10", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Image_37", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["User icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Paragraph_5", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Bg_1", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Title", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_26", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_26", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_8", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_9", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_11", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_13", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Text_2", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Text_2"]; 

	widgets.descriptionMap[["s-Text_6", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Text_6"]; 

	widgets.descriptionMap[["s-Text_11", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Text_11", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Text_11"]; 

	widgets.descriptionMap[["s-Rectangle_14", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Button dark", "s-Rectangle_14"]; 

	widgets.descriptionMap[["s-Rectangle_15", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Button dark", "s-Rectangle_15"]; 

	widgets.descriptionMap[["s-Rectangle_16", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Button dark", "s-Rectangle_16"]; 

	widgets.descriptionMap[["s-Text_8", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Text_8"]; 

	widgets.descriptionMap[["s-Text_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Text_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Text_12"]; 

	widgets.descriptionMap[["s-Text_9", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Text_9", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Text_9"]; 

	widgets.descriptionMap[["s-Image_4", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Image_2", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 1", "s-Group_6"]; 

	widgets.descriptionMap[["s-Paragraph_20", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Paragraph 1", "s-Paragraph_20"]; 

	widgets.descriptionMap[["s-Paragraph_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Paragraph 1", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_13", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Paragraph 1", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Rectangle_17", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 3", "s-Card-3"]; 

	widgets.descriptionMap[["s-Rectangle_18", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 3", "s-Card-3"]; 

	widgets.descriptionMap[["s-Title_10", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Title_10", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Title_10"]; 

	widgets.descriptionMap[["s-Paragraph_21", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Paragraph 1", "s-Paragraph_21"]; 

	widgets.descriptionMap[["s-Title_11", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Title_11", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Title_11"]; 

	widgets.descriptionMap[["s-Rectangle_19", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 3", "s-Card-3_1"]; 

	widgets.descriptionMap[["s-Rectangle_20", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_20", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Card 3", "s-Card-3_1"]; 

	widgets.descriptionMap[["s-Title_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Title_12", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Title_12"]; 

	widgets.descriptionMap[["s-Paragraph_24", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_24", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Paragraph 1", "s-Paragraph_24"]; 

	widgets.descriptionMap[["s-Title_13", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Title_13", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Title 1", "s-Title_13"]; 

	widgets.descriptionMap[["s-Input_search", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Input_search", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Search field", "s-Search-input"]; 

	widgets.descriptionMap[["s-Image_38", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_38", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Zoom icon", "s-Image_38"]; 

	widgets.descriptionMap[["s-Image_23", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "5356b72f-e3db-48c7-ae4e-c6ccb43a204c"]] = ["Telephone icon", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_10", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Image_37", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["User icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Paragraph_5", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Bg_1", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Title", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_26", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_26", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Image_23", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Telephone icon", "s-Image_23"]; 

	widgets.descriptionMap[["s-Bg", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Title_1", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Title_1", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Title 1", "s-Title_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Paragraph 1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_10", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["FB circle", "s-Image_10"]; 

	widgets.descriptionMap[["s-Image_31", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_31", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Twitter circle", "s-Image_31"]; 

	widgets.descriptionMap[["s-Title_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Title_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Title_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Title 1", "s-Title_3"]; 

	widgets.descriptionMap[["s-Title_4", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Title_4", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Title 1", "s-Title_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Paragraph 1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Input_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Paragraph_21", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Bg_7", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_7", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Text", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Image_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Paragraph_13", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Bg_9", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_9", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Text_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Image_4", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Paragraph_35", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_35", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Bg_8", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_8", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Text_1", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Image_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Paragraph_12", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Rectangle_16", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Button dark", "s-Rectangle_16"]; 

	widgets.descriptionMap[["s-Input_search", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Input_search", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Search field", "s-Search-input"]; 

	widgets.descriptionMap[["s-Image_40", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Zoom icon", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_6", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f"]] = ["Left arrow", "s-Image_6"]; 

	widgets.descriptionMap[["s-Image_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_10", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Image_37", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["User icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Paragraph_5", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Bg_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Title", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_26", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_26", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Rectangle_15", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Button dark", "s-Rectangle_15"]; 

	widgets.descriptionMap[["s-Paragraph_8", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Paragraph_9", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Paragraph_11", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_2", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_2", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_4", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_4", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_5", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_5", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Image_23", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Telephone icon", "s-Image_23"]; 

	widgets.descriptionMap[["s-Bg", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Title_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Title_1", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Title 1", "s-Title_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Paragraph 1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_10", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["FB circle", "s-Image_10"]; 

	widgets.descriptionMap[["s-Image_31", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Image_31", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Twitter circle", "s-Image_31"]; 

	widgets.descriptionMap[["s-Title_2", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Title_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Title_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Title 1", "s-Title_3"]; 

	widgets.descriptionMap[["s-Title_4", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Title_4", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Title 1", "s-Title_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Paragraph 1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Input_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Paragraph_21", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Image_4", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "9d7e289a-9886-4c55-8d5d-ff8546563551"]] = ["Left arrow", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_10", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Image_37", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["User icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Paragraph_5", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Bg_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Title", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_26", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_26", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Paragraph_9", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Paragraph_11", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_2", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_2", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_4", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_4", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Row_cell_5", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_5", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List"]; 

	widgets.descriptionMap[["s-Paragraph_25", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_25", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_27", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_27", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_30", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_30", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Team 2", "s-Team-2"]; 

	widgets.descriptionMap[["s-Paragraph_12", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Row_cell_6", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_6", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Paragraph_13", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Row_cell_7", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_7", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Paragraph_14", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Row_cell_8", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_8", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Row_cell_9", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_9", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Row_cell_10", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_10", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Row_cell_11", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Row_cell_11", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Data List", "s-Data_List_1"]; 

	widgets.descriptionMap[["s-Image_23", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Telephone icon", "s-Image_23"]; 

	widgets.descriptionMap[["s-Bg", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Title_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Title_1", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Title 1", "s-Title_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Paragraph 1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_10", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["FB circle", "s-Image_10"]; 

	widgets.descriptionMap[["s-Image_31", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_31", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Twitter circle", "s-Image_31"]; 

	widgets.descriptionMap[["s-Title_2", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Title_2", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Title 1", "s-Title_2"]; 

	widgets.descriptionMap[["s-Title_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Title_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Title 1", "s-Title_3"]; 

	widgets.descriptionMap[["s-Title_4", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Title_4", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Title 1", "s-Title_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Paragraph 1", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Input_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Paragraph_21", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Medium light footer", "s-Footer-6"]; 

	widgets.descriptionMap[["s-Rectangle_16", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Button dark", "s-Rectangle_16"]; 

	widgets.descriptionMap[["s-Input_search", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Input_search", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Search field", "s-Search-input"]; 

	widgets.descriptionMap[["s-Image_40", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Zoom icon", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_24", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_24", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Telephone icon", "s-Image_24"]; 

	widgets.descriptionMap[["s-Image_4", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "56646bc4-b8ac-4945-946b-9253c00691c3"]] = ["Left arrow", "s-Image_4"]; 

	