function initData() {
  jimData.datamasters["Data_Pel"] = [
    {
      "id": 1,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "false"
      }
    },
    {
      "id": 2,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "false"
      }
    },
    {
      "id": 3,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "true"
      }
    },
    {
      "id": 4,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "false"
      }
    },
    {
      "id": 5,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "true"
      }
    },
    {
      "id": 6,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "false"
      }
    },
    {
      "id": 7,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "true"
      }
    },
    {
      "id": 8,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "true"
      }
    },
    {
      "id": 9,
      "datamaster": "Data_Pel",
      "userdata": {
        "616159aa-43bd-4a98-8132-caec7848d189": "Name Last name",
        "b4877b4e-1705-4397-a748-bb4afc73f9c8": "Lorem ipsum",
        "0c9e7835-77ca-44b3-b8f0-36900acbc32b": "false"
      }
    }
  ];

  jimData.datamasters["D"] = [
    {
      "id": 1,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    },
    {
      "id": 2,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    },
    {
      "id": 3,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    },
    {
      "id": 4,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    },
    {
      "id": 5,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    },
    {
      "id": 6,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    },
    {
      "id": 7,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    },
    {
      "id": 8,
      "datamaster": "D",
      "userdata": {
        "c1104ad8-fedc-4ba7-9ab5-dacf30ddee39": "Lorem ipsum",
        "fe370888-dbfb-449f-b086-1cd5171b7383": "Company name",
        "621d4af4-081a-40e5-b356-0b5c2d469d8c": "Job title",
        "d85143a2-4ed3-4d73-a8e5-0f5f4594920f": "loremipsum@mail.com"
      }
    }
  ];

  jimData.datamasters["A"] = [
    {
      "id": 1,
      "datamaster": "A",
      "userdata": {
        "1f7e4612-f7c6-4311-a852-6ab53b8f9a14": "Lorem ipsum",
        "487216b0-855e-4ced-bf2b-f41eb1246999": "150,00"
      }
    },
    {
      "id": 2,
      "datamaster": "A",
      "userdata": {
        "1f7e4612-f7c6-4311-a852-6ab53b8f9a14": "Lorem ipsum",
        "487216b0-855e-4ced-bf2b-f41eb1246999": "250,00"
      }
    },
    {
      "id": 3,
      "datamaster": "A",
      "userdata": {
        "1f7e4612-f7c6-4311-a852-6ab53b8f9a14": "Lorem ipsum",
        "487216b0-855e-4ced-bf2b-f41eb1246999": "170,00"
      }
    }
  ];

  jimData.datamasters["Data"] = [
    {
      "id": 1,
      "datamaster": "Data",
      "userdata": {
        "d620f637-3fa4-4953-9a7e-13a228f7f835": "sample text",
        "ec82010f-cda1-42d4-a052-e72618beb652": "sample text",
        "4baff7e6-e4e0-4665-8402-9b087b8adb8a": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "Data",
      "userdata": {
        "d620f637-3fa4-4953-9a7e-13a228f7f835": "sample text",
        "ec82010f-cda1-42d4-a052-e72618beb652": "sample text",
        "4baff7e6-e4e0-4665-8402-9b087b8adb8a": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Data",
      "userdata": {
        "d620f637-3fa4-4953-9a7e-13a228f7f835": "sample text",
        "ec82010f-cda1-42d4-a052-e72618beb652": "sample text",
        "4baff7e6-e4e0-4665-8402-9b087b8adb8a": "sample text"
      }
    }
  ];

  jimData.datamasters["DataSiswa"] = [
    {
      "id": 1,
      "datamaster": "DataSiswa",
      "userdata": {
        "ef9ce298-ee93-48ec-85bd-fe2d9db4b4cf": "Lorem ipsum",
        "391955e6-5831-49f2-a0f4-6be443cfc324": "150,00"
      }
    },
    {
      "id": 2,
      "datamaster": "DataSiswa",
      "userdata": {
        "ef9ce298-ee93-48ec-85bd-fe2d9db4b4cf": "Lorem ipsum",
        "391955e6-5831-49f2-a0f4-6be443cfc324": "250,00"
      }
    },
    {
      "id": 3,
      "datamaster": "DataSiswa",
      "userdata": {
        "ef9ce298-ee93-48ec-85bd-fe2d9db4b4cf": "Lorem ipsum",
        "391955e6-5831-49f2-a0f4-6be443cfc324": "170,00"
      }
    }
  ];

  jimData.isInitialized = true;
}