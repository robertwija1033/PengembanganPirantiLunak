(function(window, undefined) {
  var dictionary = {
    "5356b72f-e3db-48c7-ae4e-c6ccb43a204c": "Halaman_Utama",
    "7b52d053-8ea9-4d7c-87c2-fa5be1756b3f": "Data_Pelajar",
    "9d7e289a-9886-4c55-8d5d-ff8546563551": "Data_Kelas",
    "56646bc4-b8ac-4945-946b-9253c00691c3": "Data_Pengajar",
    "c0a6adbd-e520-418f-acbe-e54cbdf84f0b": "Template 1",
    "8dc9b3bf-b6f2-40b7-adf5-2612aafcc861": "default_1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);